<?php
$id_personnel=$_GET['id_personnel'];
 ?>


<body>

<form action="ajouter_ligne_ecole.php?id_personnel=<?php echo $id_personnel ?>" method="post">
<table width="50%">
    

<td>Nom :</td> 
<td><input type="text" name="nom" size="60"></td><br /> 



<tr><tr><tr><tr><tr> 
<td>Effectif&nbsp;&nbsp; :</td>
<td> <input type="integer" name="effectif"> </td><br />
</tr>

</table></br>
<input type="submit" name="s" value="Ajouter">
</form>

<h4> <a href="responsable.php?id_personnel=<?php echo $id_personnel ?>">Retour </a></h4>

</body>
</html>