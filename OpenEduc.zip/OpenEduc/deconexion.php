<?php

header('location: Pageaccueil.php');

?>