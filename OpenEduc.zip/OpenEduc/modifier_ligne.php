<?php
$id_personnel=$_GET['id_personnel'];
 ?>

<body>
<form action="modifier_ligne_ecole.php?id_personnel=<?php echo $id_personnel?>" method="post">
<table width="50%">

<td>Saisir le numéro de la ligne :</td> 
<td><input type="text" name="id" ></td><br />
    


</table></br>
<input type="submit" name="s" value="Modifier">
</form>

<h4> <a href="responsable.php?id_personnel=<?php echo $id_personnel ?>">Retour </a></h4>



</body>
</html>