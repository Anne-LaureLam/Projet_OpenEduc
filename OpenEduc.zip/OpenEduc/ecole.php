<?php
$servername="localhost";
$dsn = 'mysql:host=localhost;dbname=openeduc;charset=utf8';
$database = "openeduc";
$username="alamouche";
$password="Vega#0405" ;

$ecole=$_GET['ecole'];

try{
$conn = new PDO($dsn, $username, $password);
//echo"Connecté à $database sur $servername avec succès";
}catch(PDOException $e){
    echo "Connexion à MySQL impossible : ", $e->getMessage();
    die(); 
}

$sql1 = 'SELECT Nom, Effectif FROM classe WHERE id_ecole='.$ecole;

$resultat = $conn->prepare($sql1);
$resultat->execute();


if (!$resultat) {
    echo "Problème de requete";
} else {
}



//echo $resultat->rowCount();
//echo $resultat->columnCount();
//$format='<li> |%50s|%8s|</li>';
/*$format=' |%50s|%8s|';
printf($format,'Nom','Effectif');
while($ligne = $resultat->fetch()) {
		printf ($format, $ligne['Nom'], $ligne['Effectif']);
	}  
      
     } // fin du else
$resultat->closeCursor(); // libère le résultat*/




?>



<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"  type="text/css" title="Exemple" href="css/style.css"/>


	
</head>
<body>
<a href="Pageaccueil.php"><img src="images/LogoOpenEduuc.PNG" alt="logo"/> <h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; OpenEduc
 </h1></a> 

<br></br>
<br></br>
    <nav>
        <ul>
          <li><a href="Projet.php">Le Projet  &ensp;</a></li>
          
          <li><a href="Partenaires.php">Partenaires du Projet  &ensp;</a></li>
          
          <li><a href="Classes.php">Les écoles et les classes  &ensp;</a></li>
          
          <li><a href="pageconnexion.php">Connexion  &ensp;</a></li>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</ul>
          
            
          
      </nav>

      <hr/>

      </br>

      <h2> Ecole <?php echo $ecole ?> </h2>

<table>
   <thead>
     <tr>
       <th>Nom</th>
       <th>Effectif</th>
     </tr>
   </thead>
   <tbody>
     <?php while($ligne = $resultat->fetch(PDO::FETCH_ASSOC)) : ?>
     <tr>
       <td><?php echo htmlspecialchars('|'.$ligne['Nom']); ?></td>
       <td><?php echo htmlspecialchars('|'.$ligne['Effectif'].'|'); ?></td>
     </tr>
     <?php endwhile; ?>
   </tbody>
 </table>
     </body>
     </html>



     



