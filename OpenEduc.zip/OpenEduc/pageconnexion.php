<?php

if (! isset($_COOKIE['user_login'])){
    setcookie('user_login', '');
    echo "user_login set";
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
<title> Connexion </title>
<meta charset="UTF-8">

<link rel="stylesheet"  type="text/css" title="Exemple" href="css/style.css"/>


	
	</head>
<body>
<a href="Pageaccueil.php"><img src="images/LogoOpenEduuc.PNG" alt="logo"/> <h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; OpenEduc
     </h1></a> 

<br></br>
<br></br>
        <nav>
            <ul>
              <li><a href="Projet.php">Le Projet  &ensp;</a></li>
              
              <li><a href="Partenaires.php">Partenaires du Projet  &ensp;</a></li>
              
              <li><a href="Classes.php">Les écoles et les classes  &ensp;</a></li>
              
              <li><a href="pageconnexion.php">Connexion  &ensp;</a></li>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</ul>
              
                
              
          </nav>

          <hr/>

          </br>
          <div class="endroit">
    <h2><b><i><u> Connexion </u></i></b></h2>
    &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
     
</br>
</br>

<?php

if(isset($_COOKIE['user_login'])){
    $ident_user=$_COOKIE['user_login'];
}else{
    $ident_user='';
}
?>

<form name="monFormulaire" id="monFormulaire" action="connect.php" method="post">
<table>
<div>
<label class="label">Identifiant :</label> 
<input class="controle" type="text" name="identifiant" id="identifiant" required pattern="[0-9a-zA-Z-\.]{3,12}" required
value="<?php echo $ident_user ?>" > 
<div>
  <input type="checkbox" id="memo" name="memo"
          >
  <label for="scales">Mémoriser l'identifiant</label>
</div>
<br><br>
<span class="resultat"></span>
                
</div>




<tr><tr><tr><tr><tr> 
<div>
<label class="label">Mot de passe :</label> 
<input class="controle" type="password" name="password" id="password" required pattern="[0-9a-zA-Z-\.]{3,12}"  required> 

<br><br>
<span class="resultat"></span>
                
</div>

</br>
<button id="envoie" type="submit" > Se Connecter </button> 
<table width="50%">
</form>

<br />
</div>


</body>
</html>

