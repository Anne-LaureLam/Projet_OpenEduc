<!DOCTYPE html>
<html lang="fr">
<head>
<title> Classes </title>
<meta charset="UTF-8">

<link rel="stylesheet"  type="text/css" title="Exemple" href="css/style.css"/>
<style>

.look {
  border: 0;
  line-height: 2.5;
  padding: 0 20px;
  font-size: 1rem;
  text-align: center;
  color: black;
  text-shadow: 1px 1px 1px #000;
  border-radius: 10px;
  background-color: blue;
  background-image: linear-gradient(to top left,
                                    rgba(0, 0, 0, .2),
                                    rgba(0, 0, 0, .2) 30%,
                                    rgba(0, 0, 0, 0));
  box-shadow: inset 2px 2px 3px rgba(255, 255, 255, .6),
              inset -2px -2px 3px rgba(0, 0, 0, .6);
}

.look:hover {
  background-color: white;
}

.look:active {
  box-shadow: inset -2px -2px 3px rgba(255, 255, 255, .6),
              inset 2px 2px 3px rgba(0, 0, 0, .6);
}

    </style>


	
	</head>
<body>
<a href="Pageaccueil.php"><img src="images/LogoOpenEduuc.PNG" alt="logo"/> <h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; OpenEduc
     </h1></a> 

<br></br>
<br></br>
        <nav>
            <ul>
              <li><a href="Projet.php">Le Projet  &ensp;</a></li>
              
              <li><a href="Partenaires.php">Partenaires du Projet  &ensp;</a></li>
              
              <li><a href="Classes.php">Les écoles et les classes  &ensp;</a></li>
              
              <li><a href="pageconnexion.php">Connexion  &ensp;</a></li>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</ul>
              
                
              
          </nav>

          <hr/>

          </br>
<div class="endroit">
    <h2><b><i><u> Les écoles et les classes </u></i></b></h2>
    <h4> <a href="historique.php">Voir l'historique </a></h4>
    &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
     
</br>
</br>



<form id="bouton1" name="bouton1" method="post" action="ecole.php?ecole=1" div class="centrer">
<button class="look" type="submit" >
    école Bischoffsheim
</button>
</form>
</div>







<form id="bouton2" name="bouton2" method="post" action="ecole.php?ecole=2" div class="centrer1">
<button class="look" type="submit">
    école Boersch
</button>
</form>
</div>








<form id="bouton3" name="bouton3" method="post" action="ecole.php?ecole=3" div class="endr">
<button class="look" type="submit">
    école Rosheim

</button>
</form>
</div>
 

