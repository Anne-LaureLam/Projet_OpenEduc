<?php

$id_personnel=$_GET['id_personnel'];
$nom=$_POST['nom'];
$effectif=$_POST['effectif'];
$idecole=$_POST['idecole'];


$servername="localhost";
$dsn = 'mysql:host=localhost;dbname=openeduc;charset=utf8';
$database = "openeduc";
$username="alamouche";
$password="Vega#0405" ;

try{
    $conn = new PDO($dsn, $username, $password);
    //echo"Connecté à $database sur $servername avec succès";
    }catch(PDOException $e){
        echo "Connexion à MySQL impossible : ", $e->getMessage();
        die(); 
    }

    /*$sqq= "SELECT id_ecole FROM personnel
    WHERE personnel.id= '$id_personnel'";
    $stmt = $conn->prepare($sqq); 
    $stmt->execute();
    $ligne=$stmt->fetch();
    $id_ecole=$ligne['id_ecole'];
    echo "id ecole = ".$id_ecole;
    */

    $sql1 = "INSERT INTO classe(Nom,Effectif,id_ecole) 
    VALUES('$nom', '$effectif', '$idecole')";

$resultat = $conn->prepare($sql1);
echo $sql1;

$resultat->execute();
if($resultat->rowCount()==1){
    $date_jour=date('Y-m-d H:i:s');

    $sql1 = "INSERT INTO historique(Dates, Fonction ,Messages) 
    VALUES('$date_jour', 'Ajout_classe', 'Nom=$nom Effectif= $effectif  ecole= $idecole id_personnel= $id_personnel')";
    echo $sql1;
    $resultat = $conn->prepare($sql1);
    $resultat->execute();
}

header('location: secretaire.php?id_personnel='.$id_personnel);



?>