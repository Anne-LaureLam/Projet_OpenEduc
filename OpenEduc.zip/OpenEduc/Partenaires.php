<!DOCTYPE html>
<html lang="fr">
<head>
<title> Partenaires </title>
<meta charset="UTF-8">

<link rel="stylesheet"  type="text/css" title="Exemple" href="css/style.css"/>


	
	</head>
<body>
<a href="Pageaccueil.php"><img src="images/LogoOpenEduuc.PNG" alt="logo"/> <h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; OpenEduc
     </h1></a> 

<br></br>
<br></br>
        <nav>
            <ul>
              <li><a href="Projet.php">Le Projet  &ensp;</a></li>
              
              <li><a href="Partenaires.php">Partenaires du Projet  &ensp;</a></li>
              
              <li><a href="Classes.php">Les écoles et les classes  &ensp;</a></li>
              
              <li><a href="pageconnexion.php">Connexion  &ensp;</a></li>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</ul>
              
                
              
          </nav>

          <hr/>

          </br>
<div class="endroit">
    <h2><b><i><u> Nos partenaires </u></i></b></h2>
    &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
     
</br>
</br>

<h3> Nos partenaires sont l'APEA (Association de Parents Eleves d'Alsace), l'école Rosheim,
     Boersch et Bischoffsheim.
 </h3>