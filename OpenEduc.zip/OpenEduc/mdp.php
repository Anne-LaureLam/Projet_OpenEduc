<?php

echo "respon1:".password_hash("respon1",PASSWORD_DEFAULT);
echo "<br>";
echo "respon2: ".password_hash("respon2",PASSWORD_DEFAULT);
echo "<br>";
echo "respon3: ".password_hash("respon3",PASSWORD_DEFAULT);
echo "<br>";
echo "secretaire1: ".password_hash("secretaire1",PASSWORD_DEFAULT);
echo "<br>";
echo "secretaire2: ".password_hash("secretaire2",PASSWORD_DEFAULT);



?>