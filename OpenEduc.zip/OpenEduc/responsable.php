<?php
$id_personnel=$_GET['id_personnel'];

$servername="localhost";
$dsn = 'mysql:host=localhost;dbname=openeduc;charset=utf8';
$database = "openeduc";
$username="alamouche";
$password="Vega#0405" ;

try{
    $conn = new PDO($dsn, $username, $password);
    //echo"Connecté à $database sur $servername avec succès";
    }catch(PDOException $e){
        echo "Connexion à MySQL impossible : ", $e->getMessage();
        die(); 
    }
    $sqq= "SELECT id_ecole FROM personnel
    WHERE personnel.id= '$id_personnel'";
    $stmt = $conn->prepare($sqq); 
    $stmt->execute();
    $ligne=$stmt->fetch();
    $id_ecole=$ligne['id_ecole'];
    

    
    $sqq= "SELECT classe.id,classe.id_ecole,classe.Nom,classe.Effectif FROM classe
    JOIN ecole ON ecole.id=classe.id_ecole
    JOIN personnel ON personnel.id_ecole=ecole.id
    WHERE personnel.id= '$id_personnel'";
    $stmt = $conn->prepare($sqq); 
    $stmt->execute();

    
        ?>

        <head>

        <link rel="stylesheet"  type="text/css" title="Exemple" href="css/style.css"/>

</head>
<style>

.look {
  border: 0;
  line-height: 2.5;
  padding: 0 20px;
  font-size: 1rem;
  text-align: center;
  color: black;
  text-shadow: 1px 1px 1px #000;
  border-radius: 10px;
  background-color: blue;
  background-image: linear-gradient(to top left,
                                    rgba(0, 0, 0, .2),
                                    rgba(0, 0, 0, .2) 30%,
                                    rgba(0, 0, 0, 0));
  box-shadow: inset 2px 2px 3px rgba(255, 255, 255, .6),
              inset -2px -2px 3px rgba(0, 0, 0, .6);
}

.look:hover {
  background-color: white;
}

.look:active {
  box-shadow: inset -2px -2px 3px rgba(255, 255, 255, .6),
              inset 2px 2px 3px rgba(0, 0, 0, .6);
}


.look1 {
  border: 0;
  line-height: 2.5;
  padding: 0 20px;
  font-size: 1rem;
  text-align: center;
  color: black;
  text-shadow: 1px 1px 1px #000;
  border-radius: 10px;
  background-color: red;
  background-image: linear-gradient(to top left,
                                    rgba(0, 0, 0, .2),
                                    rgba(0, 0, 0, .2) 30%,
                                    rgba(0, 0, 0, 0));
  box-shadow: inset 2px 2px 3px rgba(255, 255, 255, .6),
              inset -2px -2px 3px rgba(0, 0, 0, .6);
}


.look1:hover {
  background-color: white;
}

.look1:active {
  box-shadow: inset -2px -2px 3px rgba(255, 255, 255, .6),
              inset 2px 2px 3px rgba(0, 0, 0, .6);
}

    </style>
   <body>
    
        <table>
   <thead>
     <tr>
         <th>numéro de ligne</th>
        <th> id_ecole </th>
       <th>Nom</th>
       <th>Effectif</th>
     </tr>
   </thead>
   <tbody>
     <?php while($ligne= $stmt->fetch()) : ?>
     <tr>
     <td><?php echo htmlspecialchars('|'.$ligne['id']); ?></td>
     <td><?php echo htmlspecialchars('|'.$ligne['id_ecole']); ?></td>
       <td><?php echo htmlspecialchars('|'.$ligne['Nom']); ?></td>
       <td><?php echo htmlspecialchars('|'.$ligne['Effectif'].'|'); ?></td>
     </tr>
     <?php $id_ecole=$ligne['id_ecole'];
     endwhile; ?>
   </tbody>
 </table>
 <br>
 <br>
 
 <form id="bouton1" name="ajouter_ligne" action="ajouter_ligne.php?id_personnel=<?php echo $id_personnel ?>" method="post">
<button class="look" type="submit" >
    Ajouter une ligne
</button>
</form>


<form id="bouton2" name="modifier_ligne" method="post" action="modifier_ligne.php?id_personnel=<?php echo $id_personnel ?>"method="post">
<button class="look" type="submit" >
    Modifier une ligne
</button>
</form>


<form id="bouton3" name="deconnexion" method="post" action="deconexion.php" >
<button class="look1" type="submit" >
    Deconnexion
</button>
</form>



     </body>
     </html>

     <?php

    

    



