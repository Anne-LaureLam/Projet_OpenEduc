<?php
$id_personnel=$_GET['id_personnel'];
$id_ligne=$_GET['id_ligne'];
$id_ecole=$_GET['id_ecole'];
$nom=$_POST['nom'];
$effectif=$_POST['effectif'];

echo "id_personnel=", $id_personnel,"  id_ligne=",$id_ligne   ; 
echo "nom=", $nom,"  effectif",$effectif   ; 


$servername="localhost";
$dsn = 'mysql:host=localhost;dbname=openeduc;charset=utf8';
$database = "openeduc";
$username="alamouche";
$password="Vega#0405" ;
try{
    $conn = new PDO($dsn, $username, $password);
    echo"Connecté à $database sur $servername avec succès";
    }catch(PDOException $e){
        echo "Connexion à MySQL impossible : ", $e->getMessage();
        die(); 
    }
    $sqq= "UPDATE classe SET nom='$nom' , effectif= '$effectif'  WHERE  classe.id='$id_ligne' ";
    $stmt = $conn->prepare($sqq); 
    $stmt->execute();
    
    if($stmt->rowCount()==1)
    {
        $date_jour=date('Y-m-d H:i:s');
        $sqq = "INSERT INTO historique(Date, Fonction ,Message) VALUES('$date_jour', 'Modification_classe', 'Nom=$nom Effectif= $effectif  ecole= $id_ecole id_personnel= $id_personnel')";
        echo $sqq;
        $resultat = $conn->prepare($sqq);
        $resultat->execute();   

    }

    header('location: responsable.php?id_personnel='.$id_personnel);
    ?>
