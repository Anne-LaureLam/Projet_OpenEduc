<!DOCTYPE html>
<html lang="fr">
<head>
<title> Projet </title>
<meta charset="UTF-8">

<link rel="stylesheet"  type="text/css" title="Exemple" href="css/style.css"/>


	
	</head>
<body>
<a href="Pageaccueil.php"><img src="images/LogoOpenEduuc.PNG" alt="logo"/> <h1> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; OpenEduc
     </h1></a> 

<br></br>
<br></br>
        <nav>
            <ul>
              <li><a href="Projet.php">Le Projet  &ensp;</a></li>
              
              <li><a href="Partenaires.php">Partenaires du Projet  &ensp;</a></li>
              
              <li><a href="Classes.php">Les écoles et les classes  &ensp;</a></li>
              
              <li><a href="pageconnexion.php">Connexion  &ensp;</a></li>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

</ul>
              
                
              
          </nav>

          <hr/>

          </br>
<div class="endroit">
    <h2><b><i><u> Le projet </u></i></b></h2>
    &ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;&ensp;
     
</br>
</br>

<h3> Notre projet a pour but de gérer les données des écoles.<br></br>
     Nous avons pour mission de sécuriser l'accès des utilisateurs aux données pour éviter des pertes ou 
     des modifications non autorisées et respecter la confidentialité.<br></br>
    La mise en place d'un espace de connexion pour chaque utilisateur permet de résoudre de nombreux problèmes.
    Les mots de passe en base de données sont chiffrés.<br></br>
    Actuellement, nous le faisons avec 3 écoles, Rosheim, Boersch et Bischoffsheim.
 </h3>