<?php
//vérification du username et password de l'utilisateur
$servername="localhost";
$dsn = 'mysql:host=localhost;dbname=openeduc;charset=utf8';
$database = "openeduc";
$username="alamouche";
$password="Vega#0405" ;
$id_user=0;
$fonction="";
$Mot_De_Passe="";


try{
$conn = new PDO($dsn, $username, $password);
//echo"Connecté à $database sur $servername avec succès";
}catch(PDOException $e){
    echo "Connexion à MySQL impossible : ", $e->getMessage();
    die(); 
}






// vérification accès :
if(isset($_POST['identifiant'])){
 $identifiant = ($_POST['identifiant']);
 $password = ($_POST['password']);
    if($_POST['memo']){
        setcookie('user_login',$identifiant);
    }else{
        setcookie('user_login','');
    }
 
 
//echo "identifiant: ".$identifiant."  Password ".$password;

//serveur alamouche 
$sqq= "SELECT id_personnel,Fonction,Mot_De_Passe FROM utilisateur WHERE identifiant= '$identifiant'";
$stmt = $conn->prepare($sqq); 


$stmt->execute();
//echo $stmt->columnCount();
//echo $stmt->rowCount();
if($stmt->rowCount()==1){
    $ligne=$stmt->fetch();
    $id_personnel=$ligne['id_personnel'];
    $fonction=$ligne['Fonction'];
    $_POST['fonction']=$fonction;
    $Mot_De_Passe=$ligne['Mot_De_Passe'];

    if(password_verify($password,$Mot_De_Passe)){
        echo "Connexion OK";
        if(strcmp($fonction,"responsable_ecole")==0){
            header('location: responsable.php?id_personnel='.$id_personnel);

        }
        else{
            header('location: secretaire.php?id_personnel='.$id_personnel);

        }
    }
    else{
        ?>
        <script>alert("identifiant/password invalide");
    window.location.replace("pageconnexion.php");</script>
        <?php
    }
   
}

else{
    ?>
        <script>alert("identifiant/password invalide");
    window.location.replace("pageconnexion.php");</script>
        <?php
}
}else{
    ?>
        <script>alert("identifiant/password invalide");
    window.location.replace("pageconnexion.php");</script>
        <?php
}

?>