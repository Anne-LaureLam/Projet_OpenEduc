<?php
$id_personnel=$_GET['id_personnel'];
$id_ligne=$_POST['id'];

$servername="localhost";
$dsn = 'mysql:host=localhost;dbname=openeduc;charset=utf8';
$database = "openeduc";
$username="alamouche";
$password="Vega#0405" ;
try{
    $conn = new PDO($dsn, $username, $password);
    // echo"Connecté à $database sur $servername avec succès";
    }catch(PDOException $e){
        echo "Connexion à MySQL impossible : ", $e->getMessage();
        die(); 
    }
echo "id_personnel=", $id_personnel,"  id_ligne=",$id_ligne   ; 
$sqq= "SELECT Nom,Effectif,id_ecole FROM classe
WHERE  '$id_ligne'=id";
$stmt = $conn->prepare($sqq); 
$stmt->execute();
echo "nb ligne=", +$stmt->rowCount(); 
if($stmt->rowCount()==1)
{
    $ligne=$stmt->fetch();
    $nom=$ligne['Nom'];
    $effectif=$ligne['Effectif'];
    $id_ecole=$ligne['id_ecole'];
    echo "nom=", $nom,"  effectif=",$effectif,"  id_ecole=", $id_ecole   ; 


      ?>  
      <body>

      <form action="modifier_ligne_ecole_table.php?id_personnel=<?php echo $id_personnel ?>&id_ligne=<?php echo $id_ligne ?>&id_ecole=<?php echo $id_ecole ?>" method="post">
      <table width="50%">

      <td>Nom :</td> 
      <td><input type="text" name="nom"  value='<?php echo $nom  ?>'></td><br /> 
      <tr><tr><tr><tr><tr> 
      <td>Effectif&nbsp;&nbsp; :</td>
      <td> <input type="integer" name="effectif" value=<?php echo $effectif  ?>> </td><br />
     </tr>
   


      </table></br>
      <input type="submit" name="s" value="Modifier">
      </form>

      <h4> <a href="modifier_ligne.php?id_personnel=<?php echo $id_personnel ?>">Retour </a></h4>

      </body>
      </html>
      <?php
}
else
{
    echo("ligne non trouvé"); 
    sleep(1);
    //header(     )   
}
?>

    